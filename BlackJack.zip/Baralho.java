// Classe Baralho.java
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Baralho {
    private List<Carta> cartas;
    
    public Baralho() {
        cartas = new ArrayList<>();
        inicializar();
    }
    
    private void inicializar() {
        String[] naipes = {"Copas", "Espadas", "Ouros", "Paus"};
        String[] valores = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
        
        for (String naipe : naipes) {
            for (String valor : valores) {
                cartas.add(new Carta(naipe, valor));
            }
        }
    }
    
    public void embaralhar() {
        Collections.shuffle(cartas);
    }
    
    public Carta distribuirCarta() {
        if (cartas.isEmpty()) {
            inicializar();
            embaralhar();
        }
        return cartas.remove(0);
    }
    
    public int quantidadeCartas() {
        return cartas.size();
    }
}