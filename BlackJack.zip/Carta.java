// Classe Carta.java
public class Carta {
    private String naipe;
    private String valor;
    
    public Carta(String naipe, String valor) {
        this.naipe = naipe;
        this.valor = valor;
    }
    
    public String getNaipe() {
        return naipe;
    }
    
    public String getValor() {
        return valor;
    }
    
    public int getPontos() {
        switch (valor) {
            case "A":
                return 11; // Ás vale 11 inicialmente (lógica para 1 será tratada na mão)
            case "J":
            case "Q":
            case "K":
                return 10;
            default:
                return Integer.parseInt(valor);
        }
    }
    
    @Override
    public String toString() {
        return valor + " de " + naipe;
    }
}