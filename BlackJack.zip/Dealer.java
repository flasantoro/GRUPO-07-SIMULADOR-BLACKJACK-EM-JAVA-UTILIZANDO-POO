// Classe Dealer.java
public class Dealer extends Jogador {
    
    public Dealer() {
        super("Dealer");
    }
    
    @Override
    public boolean querCarta() {
        // O dealer segue regras fixas: pede carta até ter 17 ou mais pontos
        return calcularPontos() < 17;
    }
    
    public Carta getPrimeiraCarta() {
        if (mao.isEmpty()) {
            return null;
        }
        return mao.get(0);
    }
    
    // Mostra apenas a primeira carta quando o jogo está em andamento
    public String mostrarCartaVisivel() {
        if (mao.isEmpty()) {
            return nome + ": Sem cartas";
        }
        return nome + ": " + getPrimeiraCarta() + " e [Carta virada para baixo]";
    }
}