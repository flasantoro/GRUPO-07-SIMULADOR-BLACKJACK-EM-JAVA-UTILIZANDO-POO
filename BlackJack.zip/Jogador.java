// Classe Jogador.java
import java.util.ArrayList;
import java.util.List;

public class Jogador {
    protected String nome;
    protected List<Carta> mao;
    protected boolean parou;
    
    public Jogador(String nome) {
        this.nome = nome;
        this.mao = new ArrayList<>();
        this.parou = false;
    }
    
    public void receberCarta(Carta carta) {
        mao.add(carta);
    }
    
    public int calcularPontos() {
        int pontos = 0;
        int ases = 0;
        
        for (Carta carta : mao) {
            pontos += carta.getPontos();
            if (carta.getValor().equals("A")) {
                ases++;
            }
        }
        
        // Ajustar valor dos ases se necessário
        while (pontos > 21 && ases > 0) {
            pontos -= 10; // Reduz o valor do ás de 11 para 1
            ases--;
        }
        
        return pontos;
    }
    
    public boolean estourou() {
        return calcularPontos() > 21;
    }
    
    public boolean temBlackjack() {
        return mao.size() == 2 && calcularPontos() == 21;
    }
    
    public void parar() {
        this.parou = true;
    }
    
    public boolean parou() {
        return parou;
    }
    
    public String getNome() {
        return nome;
    }
    
    public List<Carta> getMao() {
        return mao;
    }
    
    public void limparMao() {
        mao.clear();
        parou = false;
    }
    
    // Método que será sobrescrito pelo Dealer
    public boolean querCarta() {
        // Implementação padrão para jogador humano
        // Na implementação real, isso seria baseado na entrada do usuário
        return calcularPontos() < 17;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(nome).append(" (").append(calcularPontos()).append(" pontos): ");
        
        for (Carta carta : mao) {
            sb.append(carta).append(", ");
        }
        
        if (!mao.isEmpty()) {
            sb.delete(sb.length() - 2, sb.length());
        }
        
        return sb.toString();
    }
}