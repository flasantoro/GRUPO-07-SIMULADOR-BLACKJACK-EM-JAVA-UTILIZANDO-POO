// Classe JogoBlackJack.java
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class JogoBlackJack {
    private Baralho baralho;
    private Dealer dealer;
    private List<Jogador> jogadores;
    private Scanner scanner;
    
    public JogoBlackJack() {
        baralho = new Baralho();
        dealer = new Dealer();
        jogadores = new ArrayList<>();
        scanner = new Scanner(System.in);
    }
    
    public void adicionarJogador(String nome) {
        jogadores.add(new Jogador(nome));
    }
    
    public void iniciarJogo() {
        System.out.println("=== Bem-vindo ao BlackJack ===");
        
        // Configuração inicial
        if (jogadores.isEmpty()) {
            System.out.print("Digite seu nome: ");
            String nome = scanner.nextLine();
            adicionarJogador(nome);
        }
        
        boolean jogarNovamente = true;
        
        while (jogarNovamente) {
            // Preparar nova rodada
            prepararRodada();
            
            // Distribuir cartas iniciais
            distribuirCartasIniciais();
            
            // Mostrar cartas iniciais
            mostrarMesa(false);
            
            // Turno dos jogadores
            for (Jogador jogador : jogadores) {
                turnoJogador(jogador);
            }
            
            // Turno do dealer
            turnoDealer();
            
            // Mostrar resultado final
            mostrarMesa(true);
            determinarVencedores();
            
            // Perguntar se quer jogar novamente
            System.out.print("Deseja jogar novamente? (s/n): ");
            String resposta = scanner.nextLine().toLowerCase();
            jogarNovamente = resposta.equals("s") || resposta.equals("sim");
        }
        
        System.out.println("Obrigado por jogar!");
    }
    
    private void prepararRodada() {
        // Limpar mãos e embaralhar baralho
        for (Jogador jogador : jogadores) {
            jogador.limparMao();
        }
        dealer.limparMao();
        baralho.embaralhar();
    }
    
    private void distribuirCartasIniciais() {
        // Cada jogador e o dealer recebem 2 cartas
        for (int i = 0; i < 2; i++) {
            for (Jogador jogador : jogadores) {
                jogador.receberCarta(baralho.distribuirCarta());
            }
            dealer.receberCarta(baralho.distribuirCarta());
        }
    }
    
    private void turnoJogador(Jogador jogador) {
        System.out.println("\n=== Turno de " + jogador.getNome() + " ===");
        
        while (!jogador.parou() && !jogador.estourou()) {
            System.out.println(jogador);
            
            if (jogador.temBlackjack()) {
                System.out.println("BlackJack! Você tem 21 pontos.");
                jogador.parar();
                break;
            }
            
            System.out.print("Deseja mais uma carta? (s/n): ");
            String resposta = scanner.nextLine().toLowerCase();
            
            if (resposta.equals("s") || resposta.equals("sim")) {
                Carta novaCarta = baralho.distribuirCarta();
                System.out.println("Você recebeu: " + novaCarta);
                jogador.receberCarta(novaCarta);
                
                if (jogador.estourou()) {
                    System.out.println(jogador);
                    System.out.println("Estourou! Você tem mais de 21 pontos.");
                }
            } else {
                jogador.parar();
                System.out.println("Você decidiu parar com " + jogador.calcularPontos() + " pontos.");
            }
        }
    }
    
    private void turnoDealer() {
        System.out.println("\n=== Turno do Dealer ===");
        
        // Verificar se todos os jogadores estouraram
        boolean todosEstouraram = true;
        for (Jogador jogador : jogadores) {
            if (!jogador.estourou()) {
                todosEstouraram = false;
                break;
            }
        }
        
        if (todosEstouraram) {
            System.out.println("Todos os jogadores estouraram. Dealer vence automaticamente.");
            dealer.parar();
            return;
        }
        
        // Dealer joga seguindo as regras
        while (!dealer.parou()) {
            System.out.println(dealer);
            
            if (dealer.querCarta()) {
                Carta novaCarta = baralho.distribuirCarta();
                System.out.println("Dealer recebeu: " + novaCarta);
                dealer.receberCarta(novaCarta);
                
                if (dealer.estourou()) {
                    System.out.println(dealer);
                    System.out.println("Dealer estourou com mais de 21 pontos!");
                    break;
                }
            } else {
                dealer.parar();
                System.out.println("Dealer parou com " + dealer.calcularPontos() + " pontos.");
            }
        }
    }
    
    private void mostrarMesa(boolean mostrarTodasAsCartas) {
        System.out.println("\n=== Mesa de Jogo ===");
        
        if (mostrarTodasAsCartas) {
            System.out.println(dealer);
        } else {
            System.out.println(dealer.mostrarCartaVisivel());
        }
        
        for (Jogador jogador : jogadores) {
            System.out.println(jogador);
        }
    }
    
    private void determinarVencedores() {
        System.out.println("\n=== Resultado ===");
        
        int pontosDealer = dealer.estourou() ? 0 : dealer.calcularPontos();
        boolean dealerTemBlackjack = dealer.temBlackjack();
        
        for (Jogador jogador : jogadores) {
            String resultado;
            
            if (jogador.estourou()) {
                resultado = "perdeu (estourou)";
            } else if (dealer.estourou()) {
                resultado = "venceu (dealer estourou)";
            } else if (jogador.temBlackjack() && !dealerTemBlackjack) {
                resultado = "venceu com BlackJack!";
            } else if (!jogador.temBlackjack() && dealerTemBlackjack) {
                resultado = "perdeu (dealer tem BlackJack)";
            } else if (jogador.calcularPontos() > pontosDealer) {
                resultado = "venceu com " + jogador.calcularPontos() + " contra " + pontosDealer;
            } else if (jogador.calcularPontos() < pontosDealer) {
                resultado = "perdeu com " + jogador.calcularPontos() + " contra " + pontosDealer;
            } else {
                resultado = "empatou com " + pontosDealer + " pontos";
            }
            
            System.out.println(jogador.getNome() + " " + resultado);
        }
    }
    
    public static void main(String[] args) {
        JogoBlackJack jogo = new JogoBlackJack();
        jogo.iniciarJogo();
    }
}